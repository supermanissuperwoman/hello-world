const BASE_URL = 'localhost';
const WS_PORT = '8000';

const WS_ADDRESS = `ws://${BASE_URL}:${WS_PORT}`;

export {WS_ADDRESS}