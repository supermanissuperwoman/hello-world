import { createStore } from 'vuex'
import { mutations } from './mutations';
import { actions } from './actions';
const store = createStore({
    state () {
      return {
        count: 1
      }
    },
    mutations: mutations,
    actions: actions
  })

  export default store;