const mutations = {
    add(state) {
      state.count++;
    },
    cut1(state) {
      state.count--;
    },
    add2(state) {
      state.count += 2;
    }
}
export {
  mutations
}